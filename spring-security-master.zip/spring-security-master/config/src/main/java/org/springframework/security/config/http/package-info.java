/**
 * Parsing of the &lt;http&gt; namespace element.
 */
package org.springframework.security.config.http;

