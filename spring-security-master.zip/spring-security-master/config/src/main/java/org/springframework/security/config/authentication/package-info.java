/**
 * Parsing of &lt;authentication-manager&gt; and related elements.
 */
package org.springframework.security.config.authentication;

