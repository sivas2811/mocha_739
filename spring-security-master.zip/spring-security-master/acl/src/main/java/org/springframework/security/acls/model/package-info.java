/**
 * Interfaces and shared classes to manage access control lists (ACLs) for domain object instances.
 */
package org.springframework.security.acls.model;

