package org.springframework.security.acls;

/**
 * Dummy domain object class
 *
 * @author Luke Taylor
 */
public final class TargetObject {

}
