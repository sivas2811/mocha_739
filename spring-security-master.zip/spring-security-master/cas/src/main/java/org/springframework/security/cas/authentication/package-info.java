/**
 * An {@code AuthenticationProvider} that can process CAS service tickets and proxy tickets.
 */
package org.springframework.security.cas.authentication;

