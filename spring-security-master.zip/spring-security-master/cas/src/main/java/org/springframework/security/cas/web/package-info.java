/**
 * Authenticates standard web browser users via CAS.
 */
package org.springframework.security.cas.web;

