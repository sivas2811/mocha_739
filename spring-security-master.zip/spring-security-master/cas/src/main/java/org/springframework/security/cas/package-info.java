/**
 * Spring Security support for Jasig's Central Authentication Service (<a href="http://www.jasig.org/cas">CAS</a>).
 */
package org.springframework.security.cas;

