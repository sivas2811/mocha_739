/**
 * Enforces security for AspectJ <code>JointPoint</code>s, delegating secure object callbacks to the calling aspect.
 */
package org.springframework.security.access.intercept.aspectj;
