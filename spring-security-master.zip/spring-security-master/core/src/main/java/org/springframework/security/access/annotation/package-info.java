/**
 * Support for JSR-250 and Spring Security {@code @Secured} annotations.  
 */
package org.springframework.security.access.annotation;
