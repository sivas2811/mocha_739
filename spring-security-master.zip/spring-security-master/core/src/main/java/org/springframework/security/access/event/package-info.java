/**
 * Authorization event and listener classes.
 */
package org.springframework.security.access.event;
