/**
 * Implements a vote-based approach to authorization decisions.
 */
package org.springframework.security.access.vote;
